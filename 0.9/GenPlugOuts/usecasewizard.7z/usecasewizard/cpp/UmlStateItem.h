#ifndef _UMLSTATEITEM_H
#define _UMLSTATEITEM_H


class UmlStateItem {
};

#endif
