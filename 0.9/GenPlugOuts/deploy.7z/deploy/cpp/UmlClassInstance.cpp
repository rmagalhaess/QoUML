
#include "UmlClassInstance.h"

