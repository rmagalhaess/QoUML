#ifndef _UMLMESSAGE_H
#define _UMLMESSAGE_H


#include "UmlBaseMessage.h"

// this class manages messages indenpendently of the diagram,
// you can modify it
class UmlMessage : public UmlBaseMessage {
};

#endif
