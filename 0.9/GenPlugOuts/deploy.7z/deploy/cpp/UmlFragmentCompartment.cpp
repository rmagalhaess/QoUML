
#include "UmlFragmentCompartment.h"

