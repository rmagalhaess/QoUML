
#include "UmlComponent.h"

#include <qdir.h>
#include <qmessagebox.h>
#include <qtextstream.h>

#include "CppSettings.h"
#include "UmlPackage.h"
#include "UmlCom.h"
#include "UmlClass.h"
#include "Dialog.h"

