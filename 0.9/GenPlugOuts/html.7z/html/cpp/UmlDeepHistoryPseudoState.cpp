
#include "UmlDeepHistoryPseudoState.h"

QCString UmlDeepHistoryPseudoState::sKind() {
  return "deep history pseudo state";
}

