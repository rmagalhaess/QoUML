
#include "UmlJoinPseudoState.h"

QCString UmlJoinPseudoState::sKind() {
  return "join pseudo state";
}

