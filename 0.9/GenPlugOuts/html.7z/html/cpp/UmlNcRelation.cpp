
#include "UmlNcRelation.h"

QCString UmlNcRelation::sKind() {
  return "non class relation";
}

void UmlNcRelation::html(QCString, unsigned int, unsigned int) {
}

void UmlNcRelation::memo_ref() {
}

