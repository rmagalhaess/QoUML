
#include "UmlTerminatePseudoState.h"

QCString UmlTerminatePseudoState::sKind() {
  return "terminate pseudo state";
}

