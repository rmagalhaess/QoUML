
#include "UmlInitialPseudoState.h"

QCString UmlInitialPseudoState::sKind() {
  return "initial pseudo state";
}

