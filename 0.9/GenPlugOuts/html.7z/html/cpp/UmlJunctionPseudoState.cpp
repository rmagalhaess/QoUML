
#include "UmlJunctionPseudoState.h"

QCString UmlJunctionPseudoState::sKind() {
  return "junction pseudo state";
}

