#ifndef _UMLSEQUENCEMESSAGE_H
#define _UMLSEQUENCEMESSAGE_H


#include "UmlBaseSequenceMessage.h"

// this class manages messages in a sequence diagram,
// you can modify it
class UmlSequenceMessage : public UmlBaseSequenceMessage {
};

#endif
