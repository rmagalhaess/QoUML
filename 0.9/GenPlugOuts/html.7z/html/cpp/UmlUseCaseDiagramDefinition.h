#ifndef _UMLUSECASEDIAGRAMDEFINITION_H
#define _UMLUSECASEDIAGRAMDEFINITION_H


#include "UmlBaseUseCaseDiagramDefinition.h"

// this class manages use case diagram definition,
// you can modify it
class UmlUseCaseDiagramDefinition : public UmlBaseUseCaseDiagramDefinition {
};

#endif
