
#include "UmlForkPseudoState.h"

QCString UmlForkPseudoState::sKind() {
  return "fork pseudo state";
}

