
#include "UmlShallowHistoryPseudoState.h"

QCString UmlShallowHistoryPseudoState::sKind() {
  return "shallow history pseudo state";
}

