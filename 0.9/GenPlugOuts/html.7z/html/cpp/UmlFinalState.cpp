
#include "UmlFinalState.h"

QCString UmlFinalState::sKind() {
  return "final state";
}

