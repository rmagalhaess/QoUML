
#include "UmlChoicePseudoState.h"

QCString UmlChoicePseudoState::sKind() {
  return "choice pseudo state";
}

