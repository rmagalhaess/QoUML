
#include "UmlActivityRegion.h"

bool UmlActivityRegion::chapterp() {
  return TRUE;
}

