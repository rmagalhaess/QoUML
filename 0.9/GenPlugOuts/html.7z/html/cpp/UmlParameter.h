#ifndef _UMLPARAMETER_H
#define _UMLPARAMETER_H


#include "UmlBaseParameter.h"

//  Represent an operation's parameter

struct UmlParameter : public UmlBaseParameter {
};

#endif
