
#include "UmlArtifact.h"
#include "FileOut.h"

bool UmlArtifact::write_if_needed(FileOut &) {
  return FALSE; // not yet implemented
}

