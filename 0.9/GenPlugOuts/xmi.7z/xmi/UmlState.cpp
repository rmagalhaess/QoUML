
#include "UmlState.h"
#include "FileOut.h"

bool UmlState::write_if_needed(FileOut &) {
  return FALSE; // not yet implemented
}

