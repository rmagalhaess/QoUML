#ifndef _CLASSGLOBALCMD_H
#define _CLASSGLOBALCMD_H


// Internal enum
enum ClassGlobalCmd {
  findClassCmd

};
#endif
