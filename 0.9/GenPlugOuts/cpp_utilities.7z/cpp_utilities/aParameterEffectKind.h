#ifndef _APARAMETEREFFECTKIND_H
#define _APARAMETEREFFECTKIND_H


enum aParameterEffectKind {
  noEffect,
  createEffect,
  readEffect,
  updateEffect,
  deleteEffect

};
#endif
