#ifndef _ANORDERING_H
#define _ANORDERING_H


enum anOrdering {
  unordered,
  ordered,
  lifo,
  fifo

};
#endif
