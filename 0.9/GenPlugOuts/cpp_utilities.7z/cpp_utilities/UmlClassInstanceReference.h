#ifndef _UMLCLASSINSTANCEREFERENCE_H
#define _UMLCLASSINSTANCEREFERENCE_H


#include "UmlBaseClassInstanceReference.h"

// this class manages class instance reference,
// you can modify it
class UmlClassInstanceReference : public UmlBaseClassInstanceReference {
};

#endif
