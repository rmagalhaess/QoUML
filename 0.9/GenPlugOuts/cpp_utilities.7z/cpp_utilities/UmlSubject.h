#ifndef _UMLSUBJECT_H
#define _UMLSUBJECT_H


#include "UmlBaseSubject.h"

// this class manages subjects, you can modify it
class UmlSubject : public UmlBaseSubject {
};

#endif
