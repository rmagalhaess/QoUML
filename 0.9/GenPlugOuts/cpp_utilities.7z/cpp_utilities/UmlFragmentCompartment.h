#ifndef _UMLFRAGMENTCOMPARTMENT_H
#define _UMLFRAGMENTCOMPARTMENT_H


#include "UmlBaseFragmentCompartment.h"

// this class manages fragments compartments,
// a fragment without separator contains one compartment you can modify it
class UmlFragmentCompartment : public UmlBaseFragmentCompartment {
};

#endif
