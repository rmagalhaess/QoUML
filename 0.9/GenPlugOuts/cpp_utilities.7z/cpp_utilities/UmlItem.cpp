
#include "UmlItem.h"

#include "UmlCom.h"
 UmlItem::~UmlItem() {
}

void UmlItem::utilities() {
  UmlCom::trace("<font face=helvetica><b>Must be applied on a <i>class</i></b></font><br><hr><br>");
}

