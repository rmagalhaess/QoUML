#ifndef _UMLCOLLABORATIONDIAGRAMDEFINITION_H
#define _UMLCOLLABORATIONDIAGRAMDEFINITION_H


#include "UmlBaseCollaborationDiagramDefinition.h"

// this class manages collaboration diagram definition,
// you can modify it
class UmlCollaborationDiagramDefinition : public UmlBaseCollaborationDiagramDefinition {
};

#endif
