#ifndef _ADIRECTION_H
#define _ADIRECTION_H


// The direction of an operation's parameter, see UmlParameter
enum aDirection {
  InputOutputDirection,
  InputDirection,
  OutputDirection

};
#endif
