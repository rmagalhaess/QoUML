#ifndef _LANGUAGE_H
#define _LANGUAGE_H


enum Language {
  None,
  Cplusplus,
  AnsiCplusplus,
  VCplusplus,
  Oracle8,
  Corba,
  Java

};
#endif
