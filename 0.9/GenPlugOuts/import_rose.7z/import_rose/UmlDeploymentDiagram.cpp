
#include "UmlDeploymentDiagram.h"
#include "File.h"
#include "UmlDeploymentView.h"

void UmlDeploymentDiagram::import(File & f, UmlDeploymentView *)
{
  //!!!!!!!!!!!
  f.skipBlock();
}

