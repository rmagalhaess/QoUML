#ifndef _PACKAGEGLOBALCMD_H
#define _PACKAGEGLOBALCMD_H


// Internal enum
enum PackageGlobalCmd {
  findNamespaceCmd,
  findPackageCmd,
  findModuleCmd,
  getProjectCmd

};
#endif
