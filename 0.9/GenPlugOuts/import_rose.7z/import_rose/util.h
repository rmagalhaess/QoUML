#ifndef UTIL_H
#define UTIL_H

extern QCString legalName(QCString);
extern QCString replace(QCString f, QCString k, QCString v);
extern bool isSep(int c);

#endif
