#ifndef _UMLSEQUENCEDIAGRAMDEFINITION_H
#define _UMLSEQUENCEDIAGRAMDEFINITION_H


#include "UmlBaseSequenceDiagramDefinition.h"

// this class manages sequence diagram definition,
// you can modify it
class UmlSequenceDiagramDefinition : public UmlBaseSequenceDiagramDefinition {
};

#endif
