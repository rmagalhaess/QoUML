#ifndef _UMLUSECASEREFERENCE_H
#define _UMLUSECASEREFERENCE_H


#include "UmlBaseUseCaseReference.h"

// this class manages use case references, you can modify it
class UmlUseCaseReference : public UmlBaseUseCaseReference {
};

#endif
