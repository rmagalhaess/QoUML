#ifndef _ALANGUAGE_H
#define _ALANGUAGE_H


enum aLanguage {
  umlLanguage,
  cppLanguage,
  javaLanguage,
  idlLanguage,
  phpLanguage

};
#endif
