
#include "UmlShallowHistoryPseudoState.h"

const char * UmlShallowHistoryPseudoState::sKind() const {
  return "shallowHistory";
}

