
#include "UmlChoicePseudoState.h"

const char * UmlChoicePseudoState::sKind() const {
  return "choice";
}

