
#include "UmlInitialPseudoState.h"

const char * UmlInitialPseudoState::sKind() const {
  return "initial";
}

