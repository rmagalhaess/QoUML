
#include "UmlJoinPseudoState.h"

const char * UmlJoinPseudoState::sKind() const {
  return "join";
}

