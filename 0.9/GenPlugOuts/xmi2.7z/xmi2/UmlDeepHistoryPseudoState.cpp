
#include "UmlDeepHistoryPseudoState.h"

const char * UmlDeepHistoryPseudoState::sKind() const {
  return "deepHistory";
}

