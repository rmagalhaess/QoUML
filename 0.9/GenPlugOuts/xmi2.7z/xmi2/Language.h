#ifndef _LANGUAGE_H
#define _LANGUAGE_H


enum Language {
  Uml,
  Cpp,
  Java

};
#endif
