
#include "UmlJunctionPseudoState.h"

const char * UmlJunctionPseudoState::sKind() const {
  return "junction";
}

