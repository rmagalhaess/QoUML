
#include "UmlForkPseudoState.h"

const char * UmlForkPseudoState::sKind() const {
  return "fork";
}

