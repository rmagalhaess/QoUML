
#include "UmlParameterSet.h"
#include "FileOut.h"

#include "UmlActivityPin.h"
void UmlParameterSet::write(FileOut &) {
  unload();
}

void UmlParameterSet::memo_incoming_flow() {

}

