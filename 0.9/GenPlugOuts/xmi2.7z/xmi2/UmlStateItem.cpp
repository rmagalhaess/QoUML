
#include "UmlStateItem.h"
#include "UmlTransition.h"

void UmlStateItem::memo_trans(UmlTransition *) {

}

void UmlStateItem::memo_incoming_trans() {
}

void UmlStateItem::add_incoming_trans(UmlTransition *) {

}

UmlStateItem::~UmlStateItem() {
}

