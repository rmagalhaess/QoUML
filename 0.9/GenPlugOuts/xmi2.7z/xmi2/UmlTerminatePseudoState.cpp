
#include "UmlTerminatePseudoState.h"

const char * UmlTerminatePseudoState::sKind() const {
  return "terminate";
}

