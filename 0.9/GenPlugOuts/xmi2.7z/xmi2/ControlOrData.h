#ifndef _CONTROLORDATA_H
#define _CONTROLORDATA_H


enum ControlOrData {
  Unset,
  IsControl,
  IsData

};
#endif
