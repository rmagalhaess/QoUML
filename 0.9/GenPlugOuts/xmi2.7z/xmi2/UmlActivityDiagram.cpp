
#include "UmlActivityDiagram.h"

void UmlActivityDiagram::memo_incoming_flow() {
}

