
#include "UmlClassItem.h"

bool UmlClassItem::check() {
  return TRUE;
}

