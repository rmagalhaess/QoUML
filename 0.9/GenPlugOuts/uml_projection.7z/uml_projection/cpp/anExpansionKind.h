#ifndef _ANEXPANSIONKIND_H
#define _ANEXPANSIONKIND_H


enum anExpansionKind {
  parallelExecution,
  iterativeExecution,
  streamExecution

};
#endif
