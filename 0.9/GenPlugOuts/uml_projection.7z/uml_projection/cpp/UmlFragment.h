#ifndef _UMLFRAGMENT_H
#define _UMLFRAGMENT_H


#include "UmlBaseFragment.h"

// this class manages fragments, you can modify it
class UmlFragment : public UmlBaseFragment {
};

#endif
