#ifndef _MISCGLOBALCMD_H
#define _MISCGLOBALCMD_H


// Internal enum
enum MiscGlobalCmd {
  byeCmd,
  traceCmd,
  messageCmd,
  toolRunningCmd,
  targetCmd,
  allMarkedCmd,
  loadCmd,
  showTraceCmd,
  traceAutoRaiseCmd

};
#endif
