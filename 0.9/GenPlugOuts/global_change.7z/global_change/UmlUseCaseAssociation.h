#ifndef _UMLUSECASEASSOCIATION_H
#define _UMLUSECASEASSOCIATION_H


#include "UmlBaseUseCaseAssociation.h"

// this class manages association between use case and actor,
// you can modify it
class UmlUseCaseAssociation : public UmlBaseUseCaseAssociation {
};

#endif
