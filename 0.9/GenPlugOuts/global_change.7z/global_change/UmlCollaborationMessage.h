#ifndef _UMLCOLLABORATIONMESSAGE_H
#define _UMLCOLLABORATIONMESSAGE_H


#include "UmlBaseCollaborationMessage.h"

// this class manages messages in a collaboration diagram,
// you can modify it
class UmlCollaborationMessage : public UmlBaseCollaborationMessage {
};

#endif
