
#include "UmlItem.h"
#include "Context.h"

 UmlItem::~UmlItem() {
}

void UmlItem::change(Context &) {
}

