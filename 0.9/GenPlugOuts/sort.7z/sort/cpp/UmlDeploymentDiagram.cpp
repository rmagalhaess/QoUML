
#include "UmlDeploymentDiagram.h"

int UmlDeploymentDiagram::orderWeight() {
  return 6;
}

