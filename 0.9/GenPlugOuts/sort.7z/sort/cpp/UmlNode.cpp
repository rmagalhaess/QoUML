
#include "UmlNode.h"

int UmlNode::orderWeight() {
  return 9;
}

