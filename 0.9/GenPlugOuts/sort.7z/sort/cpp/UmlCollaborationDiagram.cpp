
#include "UmlCollaborationDiagram.h"

int UmlCollaborationDiagram::orderWeight() {
  return 8;
}

