
#include "UmlClassDiagram.h"

int UmlClassDiagram::orderWeight() {
  return 6;
}

