
#include "UmlArtifact.h"

int UmlArtifact::orderWeight() {
  return 10;
}

