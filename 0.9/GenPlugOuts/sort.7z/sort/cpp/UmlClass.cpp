
#include "UmlClass.h"

int UmlClass::orderWeight() {
  return 10;
}

