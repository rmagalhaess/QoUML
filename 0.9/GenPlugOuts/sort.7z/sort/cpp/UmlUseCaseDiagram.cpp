
#include "UmlUseCaseDiagram.h"

int UmlUseCaseDiagram::orderWeight() {
  return 6;
}

