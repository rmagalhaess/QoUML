
#include "UmlUseCase.h"

void UmlUseCase::sort() {
  sortChildren();
}

int UmlUseCase::orderWeight() {
  return 9;
}

