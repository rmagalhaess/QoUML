
#include "UmlDeploymentView.h"

void UmlDeploymentView::sort() {
  sortChildren();
}

int UmlDeploymentView::orderWeight() {
  return 5;
}

