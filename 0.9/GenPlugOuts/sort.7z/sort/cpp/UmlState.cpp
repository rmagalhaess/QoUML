
#include "UmlState.h"

int UmlState::orderWeight() {
  return 9;
}

