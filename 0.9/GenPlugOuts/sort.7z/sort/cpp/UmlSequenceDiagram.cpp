
#include "UmlSequenceDiagram.h"

int UmlSequenceDiagram::orderWeight() {
  return 7;
}

