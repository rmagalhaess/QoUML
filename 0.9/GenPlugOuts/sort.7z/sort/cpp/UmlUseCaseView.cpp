
#include "UmlUseCaseView.h"

void UmlUseCaseView::sort() {
  sortChildren();
}

int UmlUseCaseView::orderWeight() {
  return 2;
}

