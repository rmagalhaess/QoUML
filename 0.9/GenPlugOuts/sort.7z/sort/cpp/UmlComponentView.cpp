
#include "UmlComponentView.h"

void UmlComponentView::sort() {
  sortChildren();
}

int UmlComponentView::orderWeight() {
  return 4;
}

