
#include "UmlComponent.h"

int UmlComponent::orderWeight() {
  return 9;
}

