
#include "UmlComponentDiagram.h"

int UmlComponentDiagram::orderWeight() {
  return 6;
}

