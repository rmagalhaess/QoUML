
#include "UmlClassView.h"

void UmlClassView::sort() {
  sortChildren();
}

int UmlClassView::orderWeight() {
  return 3;
}

