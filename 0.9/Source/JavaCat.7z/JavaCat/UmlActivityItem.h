#ifndef _UMLACTIVITYITEM_H
#define _UMLACTIVITYITEM_H


class UmlActivityItem {
};

#endif
